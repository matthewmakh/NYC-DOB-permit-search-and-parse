
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "brd.superproxy.io",
                port: 33335
              },
              bypassList: ["localhost"]
            }
          };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(
      function(details) {
        return {
          authCredentials: {
            username: "brd-customer-hl_4339d789-zone-isp_proxy1",
            password: "mt189eezjhvm"
          }
        };
      },
      {urls: ["<all_urls>"]},
      ['blocking']
    );
    